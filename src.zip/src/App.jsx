import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
// import Board from "../src/components/Board";
import Login from "../src/components/Login";
import MainHome from "../src/components/MainHome";
import Community from "./components/Community";
import "./css/reset.css";
import SignUp from "./components/SignUp";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<MainHome />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<SignUp />} /> 
        <Route path="/community" element={<Community />} />
      </Routes>
    </Router>
  );
}

export default App;
