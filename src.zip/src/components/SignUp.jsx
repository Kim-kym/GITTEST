import { useState } from "react";
import { useNavigate } from "react-router-dom";
import DefaultLayout from "../layouts/DefaultLayout";
import "../css/SignUp.css"

const API_URL = "http://localhost:8088/api/hpmuser";

const SignUp = () => {
  const [formData, setFormData] = useState({
    user_id: "",
    password: "",
    name: "",
    nickname: "",
    birth: "",
    phone_number: "",
    email: "",
    address: "",
  });

  const [errorMsg, setErrorMsg] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (!res.ok) {
        const err = await res.json();
        setErrorMsg(err.message || "회원가입 실패");
        return;
      }

      alert("회원가입이 완료되었습니다!");
      navigate("/login");
    } catch (err) {
      console.error("회원가입 에러:", err);
      setErrorMsg("서버 오류 또는 네트워크 오류");
    }
  };

  return (
    <DefaultLayout
    headerProps={{
        title: "회원가입",
        showBack: true,
        showIcons: { search: true },
      }}
    >
    <div className="join-container">
      <h2>회원가입</h2>
      <form onSubmit={handleSubmit} className="join-form">
        <input type="text" name="user_id" placeholder="아이디" value={formData.user_id} onChange={handleChange} />
        <input type="password" name="password" placeholder="비밀번호" value={formData.password} onChange={handleChange} />
        <input type="text" name="name" placeholder="이름" value={formData.name} onChange={handleChange} />
        <input type="text" name="nickname" placeholder="닉네임" value={formData.nickname} onChange={handleChange} />
        <input type="date" name="birth" placeholder="생년월일" value={formData.birth} onChange={handleChange} />
        <input type="text" name="phone_number" placeholder="전화번호" value={formData.phone_number} onChange={handleChange} />
        <input type="email" name="email" placeholder="이메일" value={formData.email} onChange={handleChange} />
        <input type="text" name="address" placeholder="주소" value={formData.address} onChange={handleChange} />

        {errorMsg && <p className="join-error">{errorMsg}</p>}

        <button type="submit" className="join-button">회원가입</button>
      </form>
    </div>
    </DefaultLayout>
  );
};

export default SignUp;