import "../../css/Footer.css"

const Footer = () => {
  return <div className="footer-container">Footer 입니다.</div>;
};

export default Footer;
