import Header from "../components/layout/Header/Header";
import Footer from "../components/layout/Footer";

const DefaultLayout = ({ children, headerProps }) => (
  <>
    <Header {...headerProps} />
    <main className="main-content">{children}</main>
    <Footer />
  </>
);

export default DefaultLayout;
